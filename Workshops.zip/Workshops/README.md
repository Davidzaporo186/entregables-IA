# Taller de Transfer Learning — Clasificación de 3 texturas

**Trabajo académico · quinto semestre · Keras 3**

Este repositorio contiene un **dataset preparado** de tres clases (`cesped`, `grava`, `ladrillo`), con fotografías CC0 de referencia, recortes para cada partición y seis muestras extra. Hay notebooks para exploración, entrenamiento y actividad 9.

![Muestra del dataset](vista_previa_dataset.jpg)

## Qué se está resolviendo

La idea es que el modelo reciba una imagen de un material y prediga si corresponde a césped, grava o ladrillo. La comparación incluye un modelo **EfficientNetB0 preentrenado en ImageNet**, primero congelado y después con algunas capas finales ajustadas (*fine-tuning*).

## Distribución real de archivos (sin resultados inventados)

| Clase | Train | Validation | Test | Seis imágenes nuevas | Total |
|---|---:|---:|---:|---:|---:|
| Césped | 48 | 15 | 15 | 2 | 80 |
| Grava | 48 | 15 | 15 | 2 | 80 |
| Ladrillo | 48 | 15 | 15 | 2 | 80 |
| **Total** | **144** | **45** | **45** | **6** | **240** |

`manifiesto_dataset.csv` registra el origen, región de corte, perturbaciones de imagen y SHA-256 por muestra.

## Estructura

```text
.
├── 00_exploracion_dataset.ipynb             # AUDITORÍA: ya ejecutada sobre archivos reales
├── 01_taller_transfer_learning_keras3.ipynb  # Entrenamiento / ajuste / test: requiere ejecutar
├── 02_actividad9_seis_imagenes.ipynb        # Reutiliza pesos/resultados del notebook 01
├── dataset/
│   ├── train/cesped|grava|ladrillo/
│   ├── validation/cesped|grava|ladrillo/
│   └── test/cesped|grava|ladrillo/
├── imagenes_nuevas/cesped|grava|ladrillo/   # 2 cada clase
├── fuentes_cc0/                           # fotos de referencia y procedencia
├── manifiesto_dataset.csv
├── origen_y_limitaciones_dataset.json
├── vista_previa_dataset.jpg
├── requirements.txt
└── .gitignore
```

## Cómo ejecutarlo (Google Colab)

1. Descomprime el ZIP, sin alterar los nombres de carpetas. Sube la carpeta al entorno de trabajo de Colab o coloca el proyecto en Google Drive.
2. Abre `00_exploracion_dataset.ipynb` para verificar los archivos.
3. Abre `01_taller_transfer_learning_keras3.ipynb` desde la carpeta del proyecto. Activa GPU si está disponible (Entorno de ejecución → Cambiar tipo de entorno de ejecución).
4. Instala las dependencias si faltan: `%pip install -q 'tensorflow>=2.18,<2.21' 'keras>=3,<4' scikit-learn pandas matplotlib pillow` y reinicia el entorno si se solicita.
5. Ejecuta todas las celdas del notebook 01 y **guarda las salidas**. Se descargan los pesos ImageNet si no están en la caché de Keras; este paso requiere internet.
6. Ejecuta el notebook 02 después de que el 01 haya generado `metadatos_sesion8.json` y `modelos/modelo_sesion8_final.keras`.
7. Revisa las observaciones de errores y modifica la interpretación solo si la imagen realmente lo respalda.
8. Guarda los `.ipynb` con salidas, los CSV, gráficos y `resultados/informe_final.md`, y haz commit.

## Código y criterios

- **Train+validation** se utilizan para escoger fase y entrenar; **test** se usa al final.
- El modelo principal se basa en `EfficientNetB0(weights='imagenet', include_top=False)`.
- Se entrena cabeza (`lr=1e-3`) y se ajustan las últimas 20 capas candidatas (`lr=1e-5`), conservando BatchNorm congelada.
- Se muestran todas las equivocaciones reales hasta cinco. Si hay menos de cinco, los casos extra se etiquetan como aciertos difíciles, **nunca errores inventados**.
- No se incluyen métricas de accuracy falsas ni un modelo presentado como entrenado cuando aún no lo está.

## Limitaciones metodológicas importantes

Se compone de **recortes de tres fotografías fuente**, no de 240 capturas independientes. Las regiones de origen están separadas en entrenamiento, validación, test y nuevas imágenes, pero las muestras de una misma categoría siguen relacionadas por su escena original. Por eso una accuracy alta puede ser optimista. Las seis fotos nuevas son nuevas respecto del entrenamiento y particiones, pero **no son imágenes independientes de nuevas escenas**. El siguiente paso sería recolectar varias fotos por material y separar datos por fotografía (no por recorte).

Este proyecto es una alternativa de prototipado cuando no hay dataset personal; si el profesor exige **fotos personalmente tomadas** o **seis escenas independientes**, el material suministrado **no reemplaza ese requisito**.

## Origen y licencias

Las fuentes fueron incluidas de `scikit-image`, imágenes de ejemplo `skimage.data.grass()`, `gravel()` y `brick()`. La documentación las describe como CC0 (dominio público/renuncia de derechos). Las imágenes se transformaron mediante recortes y pequeñas variaciones fotométricas. Ver [documentación de scikit-image](https://scikit-image.org/docs/stable/api/skimage.data.html).

**Fuentes técnicas:** [Keras EfficientNetB0](https://keras.io/api/applications/efficientnet/efficientnet_models/), [guía oficial de fine-tuning](https://keras.io/guides/transfer_learning/).

## Estado de esta versión

- Datos: **creados, comprobados y incluidos**.
- Exploración de datos: **ejecutada** (cuaderno 00).
- Entrenamiento de la red Keras y test: **pendientes de ejecución** en entorno con TensorFlow y acceso a los pesos ImageNet. Los resultados reales se producirán al ejecutar el cuaderno 01.
